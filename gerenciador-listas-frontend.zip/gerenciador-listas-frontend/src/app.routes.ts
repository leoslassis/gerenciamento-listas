import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', loadComponent: () => import('./features/listas/listas-home.component').then(m => m.ListasHomeComponent) },
  { path: 'listas/novo', loadComponent: () => import('./features/listas/criar-lista.component').then(m => m.CriarListaComponent) },
  { path: 'listas/:nome', loadComponent: () => import('./features/itens/itens-lista.component').then(m => m.ItensListaComponent) },
  { path: '**', redirectTo: '' }
];
