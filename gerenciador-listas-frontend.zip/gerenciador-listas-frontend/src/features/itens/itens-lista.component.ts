import { Component, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ApiService } from '../../app/api';
import { CriarItemDialogComponent } from './criar-item-dialog.component';
import { Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

type SchemaShape = { properties?: Record<string, any> } | Record<string, any> | null;

@Component({
  standalone: true,
  selector: 'app-itens-lista',
  imports: [
    CommonModule, FormsModule, DatePipe,
    MatTableModule,
    MatFormFieldModule, MatInputModule, MatButtonModule, MatIconModule,
    MatDialogModule, MatSnackBarModule, MatProgressSpinnerModule
  ],
  template: `
  <div class="container">
    <div class="header">
      <h2>Itens da Lista: {{ nome }}</h2>
      <button mat-raised-button color="primary" (click)="abrirCriarItem()">
        <span class="material-icons">add</span>&nbsp;Novo item
      </button>
    </div>

    <div class="card">
      <!-- Filtros por campo (schema) -->
      <div *ngIf="schemaKeys.length > 0; else filtrosLivres" class="filtros-grid">
        <div *ngFor="let k of schemaKeys" class="filtro-campo">
          <mat-form-field appearance="outline" style="width:100%">
            <mat-label>{{ k }}</mat-label>
            <input
              matInput
              [type]="inputType(k)"
              [(ngModel)]="filtros[k]"
              (ngModelChange)="onFiltroChanged()"
            />
          </mat-form-field>
        </div>
      </div>

      <!-- Texto livre (sem schema) -->
      <ng-template #filtrosLivres>
        <mat-form-field appearance="outline" style="width:100%">
          <mat-label>filtros (k=v;k2=30)</mat-label>
          <input matInput [(ngModel)]="filtrosTexto" (ngModelChange)="onFiltroChanged()" />
        </mat-form-field>
      </ng-template>

      <div *ngIf="loading" class="loading">
        <mat-progress-spinner mode="indeterminate"></mat-progress-spinner>
      </div>

      <ng-container *ngIf="!loading">
        <div class="scroll-wrap">
          <table mat-table [dataSource]="dados" class="full-width-table">
            <!-- ID -->
            <ng-container matColumnDef="id">
              <th mat-header-cell *matHeaderCellDef>ID</th>
              <td mat-cell *matCellDef="let row">{{ row.id }}</td>
            </ng-container>

            <!-- Data Inclusão (metadado) -->
            <ng-container matColumnDef="dataInclusao">
              <th mat-header-cell *matHeaderCellDef>Incluído em</th>
              <td mat-cell *matCellDef="let row">
                {{ row.dataInclusao | date:'short' }}
              </td>
            </ng-container>

            <!-- Colunas dinâmicas conforme schema -->
            <ng-container *ngFor="let k of schemaKeys" [matColumnDef]="k">
              <th mat-header-cell *matHeaderCellDef>{{ k }}</th>
              <td mat-cell *matCellDef="let row">{{ row.dados?.[k] }}</td>
            </ng-container>

            <!-- Fallback quando não há schema -->
            <ng-container *ngIf="schemaKeys.length === 0" matColumnDef="dados">
              <th mat-header-cell *matHeaderCellDef>Dados</th>
              <td mat-cell *matCellDef="let row"><pre style="margin:0">{{ row.dados | json }}</pre></td>
            </ng-container>

            <!-- Ações (excluir) -->
            <ng-container matColumnDef="acoes">
              <th mat-header-cell *matHeaderCellDef></th>
              <td mat-cell *matCellDef="let row" style="text-align:right">
                <button mat-icon-button color="warn"
                        (click)="excluir(row.id)"
                        aria-label="Excluir item">
                  <mat-icon>delete</mat-icon>
                </button>
              </td>
            </ng-container>

            <tr mat-header-row *matHeaderRowDef="cols"></tr>
            <tr mat-row *matRowDef="let row; columns: cols;"></tr>
          </table>
        </div>
      </ng-container>
    </div>
  </div>
  `,
  styles: [`
    .container { padding: 16px; }
    .header { display:flex; align-items:center; justify-content:space-between; margin-bottom:8px; }
    .card { background: #fff; border-radius: 12px; padding: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.08); }
    .scroll-wrap { max-height: 60vh; overflow: auto; border-radius: 8px; }
    .full-width-table { width: 100%; min-width: 720px; }
    .filtros-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
      gap: 12px;
      margin-bottom: 8px;
      align-items: end;
    }
    .loading { display:flex; justify-content:center; padding:24px }
  `]
})
export class ItensListaComponent implements OnInit {
  nome = '';
  filtrosTexto = '';
  filtros: Record<string, any> = {};
  dados: any[] = [];
  cols: string[] = ['id', 'dataInclusao', 'dados', 'acoes'];
  loading = false;
  schema: SchemaShape = null;
  schemaKeys: string[] = [];

  private filtroChange$ = new Subject<void>();
  private readonly MIN_CHARS = 3;
  private lastQueryKey = '';

  constructor(
    private route: ActivatedRoute,
    private api: ApiService,
    private dialog: MatDialog,
    private snack: MatSnackBar
  ) {}

  ngOnInit() {
    this.nome = this.route.snapshot.paramMap.get('nome') || '';
    this.filtroChange$.pipe(debounceTime(350)).subscribe(() => this.consultarAuto());

    this.api.buscarLista(this.nome).subscribe({
      next: (lista: any) => {
        this.schema = lista?.schema ?? null;
        this.schemaKeys = this.extrairChavesSchema(this.schema);
        this.cols = this.schemaKeys.length > 0 ? ['id', 'dataInclusao', ...this.schemaKeys, 'acoes'] : ['id', 'dataInclusao', 'dados', 'acoes'];
        this.consultar(); // carga inicial
      },
      error: () => this.consultar()
    });
  }

  onFiltroChanged() { this.filtroChange$.next(); }

  extrairChavesSchema(s: SchemaShape): string[] {
    if (!s) return [];
    const props = (s as any).properties ?? s;
    return Object.keys(props || {});
  }

  inputType(k: string): string {
    const props = (this.schema as any)?.properties ?? (this.schema as any);
    const t = props?.[k]?.type;
    if (t === 'number' || t === 'integer') return 'number';
    if (t === 'boolean') return 'text';
    return 'text';
  }

  private parseFiltrosLivres(s: string): Record<string, string> {
    const out: Record<string, string> = {};
    (s || '').split(';').map(x => x.trim()).filter(Boolean).forEach(pair => {
      const [k, v] = pair.split('=');
      if (k && v != null) out[k.trim()] = v.trim();
    });
    return out;
  }

  private consultarAuto() {
    if (this.schemaKeys.length === 0) {
      const txt = (this.filtrosTexto || '').trim();
      if (txt.length === 0) return this.consultar({});
      if (txt.length < this.MIN_CHARS) return;
      return this.consultar(this.parseFiltrosLivres(txt));
    }

    const efetivos: Record<string, any> = {};
    let temAlgumFiltro = false;
    let aguardando = false;

    const props = (this.schema as any)?.properties ?? (this.schema as any);

    for (const k of this.schemaKeys) {
      const v = this.filtros[k];
      if (v === undefined || v === null || v === '') continue;

      const tipo = props?.[k]?.type || typeof v;
      if (tipo === 'string' || typeof v === 'string') {
        const s = String(v).trim();
        if (s.length === 0) continue;
        if (s.length < this.MIN_CHARS) { aguardando = true; continue; }
        efetivos[k] = s;
        temAlgumFiltro = true;
      } else {
        efetivos[k] = v;
        temAlgumFiltro = true;
      }
    }

    if (!temAlgumFiltro && !aguardando) return this.consultar({});
    if (aguardando) return;
    this.consultar(efetivos);
  }

  consultar(filtros?: Record<string, any>) {
    this.loading = true;
    const efetivos = filtros ?? (this.schemaKeys.length > 0 ? this.filtros : this.parseFiltrosLivres(this.filtrosTexto));

    const key = JSON.stringify(efetivos || {});
    if (key === this.lastQueryKey && this.dados.length && !this.loading) return;
    this.lastQueryKey = key;

    this.api.buscarItens(this.nome, efetivos as any).subscribe({
      next: (itens: any[]) => { this.dados = itens || []; this.loading = false; },
      error: (e) => {
        this.loading = false;
        this.snack.open(e?.error?.erro || e?.error?.message || 'Erro ao buscar itens', 'OK', { duration: 3500 });
      }
    });
  }

  abrirCriarItem() {
    if (!this.schema) { this.snack.open('Schema não encontrado para esta lista.', 'OK', { duration: 2500 }); return; }
    const ref = this.dialog.open(CriarItemDialogComponent, { data: { schema: this.schema, nomeLista: this.nome }, width: '600px' });
    ref.afterClosed().subscribe((dados: any) => {
      if (!dados) return;
      this.api.adicionarItem(this.nome, dados).subscribe({
        next: _ => { this.snack.open('Item criado com sucesso!', 'OK', { duration: 2500 }); this.consultar({}); },
        error: e => this.snack.open(e?.error?.erro || e?.error?.message || 'Falha ao criar item', 'OK', { duration: 3500 })
      });
    });
  }

  excluir(id: string) {
    if (!confirm('Excluir este item?')) return;
    this.api.removerItem(this.nome, id).subscribe({
      next: () => {
        this.snack.open('Item removido!', 'OK', { duration: 2000 });
        this.consultar({});
      },
      error: e => this.snack.open(
        e?.error?.erro || e?.error?.message || 'Falha ao remover item',
        'OK', { duration: 3500 }
      )
    });
  }
}
