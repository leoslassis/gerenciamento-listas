import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { ApiService } from '../../app/api';
import { firstValueFrom } from 'rxjs';

type CampoDef = {
  name: string;
  label: string;
  type: 'string' | 'number' | 'boolean' | 'integer'; // inclui 'integer'
  required: boolean;
  unique: boolean;
};

@Component({
  standalone: true,
  selector: 'app-criar-item-dialog',
  imports: [
    CommonModule, MatDialogModule, ReactiveFormsModule,
    MatFormFieldModule, MatInputModule, MatButtonModule, MatSelectModule, MatSnackBarModule
  ],
  template: `
  <h2 mat-dialog-title>Novo item</h2>
  <div mat-dialog-content>
    <form [formGroup]="form" class="form-grid">
      <div class="campo" *ngFor="let c of campos">
        <mat-form-field appearance="outline" style="width:100%">
          <mat-label>
            {{ c.label || c.name }}
            <span *ngIf="c.unique" class="badge-unique">Único</span>
          </mat-label>
          <input
            matInput
            [type]="inputType(c)"
            [formControlName]="c.name"
            [placeholder]="c.label || c.name"
          />
          <mat-hint *ngIf="c.required">Obrigatório</mat-hint>
        </mat-form-field>
      </div>
    </form>
  </div>
  <div mat-dialog-actions style="justify-content: flex-end">
    <button mat-stroked-button (click)="fechar()">Cancelar</button>
    <button mat-raised-button color="primary" (click)="salvar()" [disabled]="form.invalid || salvando">
      {{ salvando ? 'Salvando...' : 'Salvar' }}
    </button>
  </div>
  `,
  styles: [`
    .form-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
      gap: 12px;
      align-items: start;
    }
    .badge-unique {
      display: inline-block;
      margin-left: 8px;
      padding: 0 6px;
      font-size: 11px;
      border-radius: 10px;
      background: rgba(255, 193, 7, 0.2);
      color: #b26a00;
      vertical-align: middle;
    }
  `]
})
export class CriarItemDialogComponent implements OnInit {
  form!: FormGroup;
  campos: CampoDef[] = [];
  salvando = false;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { nomeLista?: string; schema: any },
    private ref: MatDialogRef<CriarItemDialogComponent>,
    private api: ApiService,
    private snack: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.montarCamposAPartirDoSchema(this.data?.schema);
    const controls: Record<string, FormControl> = {};
    for (const c of this.campos) {
      const validators = c.required ? [Validators.required] : [];
      controls[c.name] = new FormControl(null, validators);
    }
    this.form = new FormGroup(controls);
  }

  private montarCamposAPartirDoSchema(schema: any) {
    // aceita {properties:{...}} ou shorthand {...}
    const props = schema?.properties ?? schema;
    this.campos = Object.entries(props || {}).map(([name, def]: [string, any]) => ({
      name,
      label: def?.title || name,
      type: (def?.type as any) || 'string',
      required: !!(schema?.required || []).includes(name),
      unique: !!def?.unique
    }));
  }

  inputType(c: CampoDef): string {
    if (c.type === 'number' || c.type === 'integer') return 'number';
    if (c.type === 'boolean') return 'text'; // poderia ser select true/false
    return 'text';
  }

  async salvar() {
    if (this.form.invalid) {
      this.snack.open('Preencha os campos obrigatórios.', 'OK', { duration: 2500 });
      return;
    }

    const dados: Record<string, any> = {};
    for (const c of this.campos) {
      let v = this.form.get(c.name)?.value;
      if (c.type === 'number' || c.type === 'integer') {
        v = (v === '' || v === null) ? null : Number(v);
      }
      dados[c.name] = v;
    }

    // ---- Verificação de unicidade (pré-save) ----
    try {
      this.salvando = true;

      const nomeLista = this.data?.nomeLista;
      // se por algum motivo não veio, pulamos a verificação (o backend ainda garante)
      if (nomeLista) {
        const uniqueCampos = this.campos.filter(c =>
          c.unique && dados[c.name] != null && String(dados[c.name]).trim() !== ''
        );

        for (const c of uniqueCampos) {
          const payload = { [c.name]: dados[c.name] };
          const existe = await firstValueFrom(this.api.verificarExistencia(nomeLista, payload));
          if (existe === true) {
            this.snack.open(`Já existe um item com o mesmo valor em "${c.label || c.name}".`, 'OK', { duration: 3500 });
            this.salvando = false;
            return; // bloqueia o submit
          }
        }
      }

      // Tudo certo -> fecha retornando os dados para o pai salvar
      this.ref.close(dados);

    } catch (e: any) {
      this.salvando = false;
      const msg = e?.error?.erro || e?.error?.message || 'Falha ao verificar unicidade';
      this.snack.open(msg, 'OK', { duration: 3500 });
    }
  }

  fechar() { this.ref.close(null); }
}
