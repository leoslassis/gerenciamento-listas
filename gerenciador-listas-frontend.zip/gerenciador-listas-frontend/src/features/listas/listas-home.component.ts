import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { ApiService } from '../../app/api';

@Component({
  standalone: true,
  selector: 'app-listas-home',
  imports: [CommonModule, RouterLink, MatTableModule, MatButtonModule, MatIconModule],
  template: `
    <div class="container">
      <div class="header">
        <h2 class="title">Listas</h2>
        <a mat-raised-button color="primary" routerLink="/listas/novo">
          <span class="material-icons">add</span>&nbsp;Nova Lista
        </a>
      </div>

      <div class="card">
        <div class="scroll-wrap">
          <table mat-table [dataSource]="listas" class="full-width-table">
            <!-- Nome -->
            <ng-container matColumnDef="nome">
              <th mat-header-cell *matHeaderCellDef>Nome</th>
              <td mat-cell *matCellDef="let l">
                <a [routerLink]="['/listas', l.nome]">{{ l.nome }}</a>
              </td>
            </ng-container>

            <!-- Descrição -->
            <ng-container matColumnDef="descricao">
              <th mat-header-cell *matHeaderCellDef>Descrição</th>
              <td mat-cell *matCellDef="let l">{{ l.descricao }}</td>
            </ng-container>

            <!-- Ações -->
            <ng-container matColumnDef="acoes">
              <th mat-header-cell *matHeaderCellDef></th>
              <td mat-cell *matCellDef="let l" style="text-align:right">
                <button mat-icon-button color="warn" (click)="excluir(l.nome)" aria-label="Excluir lista">
                  <mat-icon>delete</mat-icon>
                </button>
              </td>
            </ng-container>

            <tr mat-header-row *matHeaderRowDef="cols"></tr>
            <tr mat-row *matRowDef="let row; columns: cols;"></tr>
          </table>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .container { padding: 16px; }
    .header { display:flex; align-items:center; justify-content:space-between; margin-bottom:12px; }
    .title { margin:0 }
    .card { background: #fff; border-radius: 12px; padding: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.08); }
    .scroll-wrap { max-height: 60vh; overflow: auto; border-radius: 8px; }
    .full-width-table { width: 100%; min-width: 600px; }
  `]
})
export class ListasHomeComponent implements OnInit {
  listas: any[] = [];
  cols = ['nome','descricao','acoes'];

  constructor(private api: ApiService, private router: Router) {}

  ngOnInit() {
    this.listar();
  }

  listar() {
    this.api.listarListas().subscribe({
      next: (ls: any) => this.listas = ls || [],
      error: (e) => alert(e?.error?.erro || e?.error?.message || 'Erro ao carregar listas')
    });
  }

  excluir(nome: string) {
    if (!confirm(`Excluir a lista "${nome}" e TODOS os seus itens?`)) return;
    this.api.removerLista(nome).subscribe({
      next: () => this.listar(),
      error: (e) => alert(e?.error?.erro || e?.error?.message || 'Erro ao excluir lista')
    });
  }
}
