import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

import { ApiService } from '../../app/api';

type Campo = {
  name: string;  // chave técnica do JSON
  label: string; // rótulo amigável (se vazio, usamos name)
  type: 'string' | 'number' | 'boolean' | 'integer';
  required: boolean;
  unique: boolean;
};

@Component({
  standalone: true,
  selector: 'app-criar-lista',
  imports: [
    CommonModule, FormsModule, RouterLink,
    MatFormFieldModule, MatInputModule, MatSelectModule, MatCheckboxModule,
    MatButtonModule, MatIconModule, MatCardModule, MatSnackBarModule
  ],
  template: `
  <div class="container">
    <div class="header">
      <h2>Criar Lista</h2>
      <a mat-stroked-button routerLink="/listas">Voltar</a>
    </div>

    <mat-card class="card">
      <form #f="ngForm" (ngSubmit)="salvar(f)">
        <!-- Nome e Descrição -->
        <div class="row">
          <mat-form-field appearance="outline" style="max-width:420px; width:100%">
            <mat-label>Nome da lista*</mat-label>
            <input
              matInput
              [(ngModel)]="nome"
              name="nome"
              required
              placeholder="minúsculas e underscore (ex.: cpf_restrito)">
            <mat-hint>Use apenas minúsculas e underscore (_)</mat-hint>
          </mat-form-field>

          <mat-form-field appearance="outline" style="flex:1; min-width:280px">
            <mat-label>Descrição</mat-label>
            <input matInput [(ngModel)]="descricao" name="descricao" placeholder="opcional">
          </mat-form-field>
        </div>

        <h3>Campos do Schema</h3>

        <div class="campos">
          <div class="campo" *ngFor="let c of campos; let i = index">
            <mat-form-field appearance="outline">
              <mat-label>Nome*</mat-label>
              <input matInput [(ngModel)]="c.name" name="name_{{i}}" required placeholder="ex.: cpf">
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Rótulo</mat-label>
              <input matInput [(ngModel)]="c.label" name="label_{{i}}" placeholder="ex.: CPF">
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Tipo</mat-label>
              <mat-select [(ngModel)]="c.type" name="type_{{i}}">
                <mat-option value="string">string</mat-option>
                <mat-option value="number">number</mat-option>
                <mat-option value="integer">integer</mat-option>
                <mat-option value="boolean">boolean</mat-option>
              </mat-select>
            </mat-form-field>

            <mat-checkbox [(ngModel)]="c.required" name="req_{{i}}">Obrigatório</mat-checkbox>
            <mat-checkbox [(ngModel)]="c.unique" name="uniq_{{i}}">Único</mat-checkbox>

            <button mat-icon-button color="warn" (click)="removerCampo(i)" type="button" aria-label="Remover campo">
              <mat-icon>delete</mat-icon>
            </button>
          </div>
        </div>

        <div class="acoes">
          <button mat-stroked-button type="button" (click)="adicionarCampo()">
            <mat-icon>add</mat-icon>&nbsp;Adicionar campo
          </button>

          <span class="flex"></span>

          <button mat-raised-button color="primary" type="submit" [disabled]="camposInvalidos()">
            Salvar
          </button>
        </div>
      </form>
    </mat-card>
  </div>
  `,
  styles: [`
    .container { padding: 16px; }
    .header { display:flex; align-items:center; justify-content:space-between; margin-bottom:12px; }
    .card { padding: 12px; }
    .row { display:flex; gap: 12px; margin-bottom: 12px; flex-wrap: wrap; }
    .campos { display:flex; flex-direction: column; gap:12px; }
    .campo {
      display:grid;
      grid-template-columns: repeat(3, minmax(160px, 1fr)) auto auto auto;
      gap:12px; align-items:center;
    }
    .acoes { display:flex; gap:12px; align-items:center; margin-top: 12px; }
    .flex { flex:1 }
    @media (max-width: 900px) {
      .campo { grid-template-columns: repeat(2, minmax(160px, 1fr)) auto auto auto; }
    }
    @media (max-width: 600px) {
      .campo { grid-template-columns: 1fr; }
    }
  `]
})
export class CriarListaComponent {
  nome = '';
  descricao = '';
  campos: Campo[] = [
    { name: '', label: '', type: 'string', required: true, unique: false }
  ];

  constructor(private api: ApiService, private router: Router, private snack: MatSnackBar) {}

  adicionarCampo() {
    this.campos.push({ name: '', label: '', type: 'string', required: false, unique: false });
  }

  removerCampo(i: number) {
    this.campos.splice(i, 1);
  }

  camposInvalidos(): boolean {
    if (this.campos.length === 0) return true;
    // nome do campo é obrigatório e sem espaços
    if (this.campos.some(c => !c.name || /\s/.test(c.name))) return true;
    // nome da lista precisa seguir o padrão
    if (!/^[a-z0-9]+(_[a-z0-9]+)*$/.test(this.nome || '')) return true;
    return false;
  }

  private montarSchema() {
    // JSON Schema-like com suporte a "unique" e "title" (rótulo)
    const properties: Record<string, any> = {};
    const required: string[] = [];

    for (const c of this.campos) {
      properties[c.name] = {
        type: c.type,
        title: (c.label && c.label.trim() !== '') ? c.label.trim() : c.name, // se rótulo vazio, usa o nome
        unique: !!c.unique
      };
      if (c.required) required.push(c.name);
    }

    const schema: any = { properties };
    if (required.length > 0) schema.required = required;
    return schema;
  }

  salvar(form: NgForm) {
    if (this.camposInvalidos()) {
      this.snack.open('Preencha o nome da lista e os campos corretamente (nomes sem espaços).', 'OK', { duration: 2500 });
      return;
    }

    const payload = {
      nome: this.nome,
      descricao: this.descricao || '',
      schema: this.montarSchema()
    };

    this.api.criarLista(payload).subscribe({
      next: () => {
        this.snack.open('Lista criada com sucesso!', 'OK', { duration: 2000 });
        this.router.navigate(['/listas']);
      },
      error: (e) => {
        const msg = e?.error?.erro || e?.error?.message || 'Falha ao criar lista';
        this.snack.open(msg, 'OK', { duration: 3500 });
      }
    });
  }
}
