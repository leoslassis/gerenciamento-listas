import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { v4 as uuidv4 } from 'uuid';

const API_BASE = 'http://localhost:8080';

@Injectable({ providedIn: 'root' })
export class ApiService {
  constructor(private http: HttpClient) {}

  private headers(): HttpHeaders {
    return new HttpHeaders({
      'X-Correlation-Id': uuidv4(),
      'Cache-Control': 'no-cache',
      'Pragma': 'no-cache'
    });
  }

  // ---- Listas ----
  listarListas() {
    return this.http.get<any[]>(`${API_BASE}/listas`, { headers: this.headers() });
  }

  buscarLista(nome: string) {
    return this.http.get(`${API_BASE}/listas/${encodeURIComponent(nome)}`, { headers: this.headers() });
  }

  criarLista(payload: any) {
    return this.http.post(`${API_BASE}/listas`, payload, { headers: this.headers() });
  }

  removerLista(nome: string) {
    return this.http.delete(`${API_BASE}/listas/${encodeURIComponent(nome)}`, { headers: this.headers() });
  }

  // ---- Itens ----
  adicionarItem(nome: string, dados: any) {
    return this.http.post(`${API_BASE}/listas/${encodeURIComponent(nome)}/itens`, dados, { headers: this.headers() });
  }

  buscarItens(nome: string, filtros: Record<string, string> = {}) {
    let params = new HttpParams();
    Object.entries(filtros).forEach(([k, v]) => {
      if (v != null && v !== '') params = params.set(String(k), String(v));
    });
    return this.http.get<any[]>(
      `${API_BASE}/listas/${encodeURIComponent(nome)}/itens`,
      { params, headers: this.headers() }
    );
  }

  atualizarItem(nome: string, idItem: string, dados: any) {
    return this.http.patch(`${API_BASE}/listas/${encodeURIComponent(nome)}/itens/${encodeURIComponent(idItem)}`, dados, { headers: this.headers() });
  }

  removerItem(nome: string, idItem: string) {
    return this.http.delete(`${API_BASE}/listas/${encodeURIComponent(nome)}/itens/${encodeURIComponent(idItem)}`, { headers: this.headers() });
  }

  // ---- Verificação de existência (unicidade) ----
  verificarExistencia(nome: string, dados: Record<string, any>) {
    return this.http.post<boolean>(
      `${API_BASE}/listas/${encodeURIComponent(nome)}/verificar`,
      dados,
      { headers: this.headers() }
    );
  }
}
