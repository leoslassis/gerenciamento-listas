import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, MatToolbarModule, MatButtonModule],
  template: `
    <mat-toolbar color="primary">
      <span style="font-weight:600">Gerenciador de Listas</span>
      <span style="flex:1 1 auto"></span>
      <a mat-button routerLink="/" [routerLinkActive]="'active'">Listas</a>
      <a mat-button routerLink="/listas/novo" [routerLinkActive]="'active'">Nova Lista</a>
    </mat-toolbar>

    <div class="container" style="margin-top:12px">
      <router-outlet></router-outlet>
    </div>
  `
})
export class AppComponent {}
