package com.bancoacme.gerenciadorlistas.infrastructure.repository.mapper;

import com.bancoacme.gerenciadorlistas.domain.model.Lista;
import com.bancoacme.gerenciadorlistas.infrastructure.repository.entity.ListaMongo;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.*;

public final class ListaMapper {
  private static final ObjectMapper MAPPER = new ObjectMapper();
  private static final TypeReference<Map<String,Object>> MAP_TYPE = new TypeReference<>() {};

  private ListaMapper(){}

  public static Lista toDomain(ListaMongo m) {
    Map<String,Object> raw = m.getSchema();
    Map<String,Object> plain = sanitize(raw);              // limpa _children/_value/etc.
    JsonNode schemaNode = (plain == null) ? null : MAPPER.valueToTree(plain);
    return new Lista(m.getNome(), m.getDescricao(), schemaNode);
  }

  public static ListaMongo toMongo(Lista d) {
    Map<String,Object> schemaMap = (d.getSchema() == null) ? null : MAPPER.convertValue(d.getSchema(), MAP_TYPE);
    return new ListaMongo(d.getNome(), d.getDescricao(), schemaMap);
  }

  @SuppressWarnings("unchecked")
  private static Map<String,Object> sanitize(Object node) {
    if (node == null) return null;
    if (!(node instanceof Map<?,?> map)) return (Map<String,Object>) node;

    if (map.containsKey("_value") && map.size() <= 2) {
      return Map.of("$__leaf", map.get("_value")); // marcador temporário
    }

    if (map.containsKey("_children")) {
      Object ch = map.get("_children");
      Map<String,Object> out = new LinkedHashMap<>();
      if (ch instanceof Map<?,?> children) {
        for (var e : children.entrySet()) {
          String k = String.valueOf(e.getKey());
          Object v = e.getValue();
          Object sv = sanitize(v);
          if (sv instanceof Map<?,?> m2 && m2.containsKey("$__leaf") && m2.size()==1) {
            out.put(k, m2.get("$__leaf"));
          } else {
            out.put(k, sv);
          }
        }
      }
      return out;
    }

    Map<String,Object> out = new LinkedHashMap<>();
    for (var e : map.entrySet()) {
      String k = String.valueOf(e.getKey());
      if (k.startsWith("_")) continue;
      Object v = e.getValue();
      if (v instanceof Map<?,?>) {
        Object sv = sanitize(v);
        if (sv instanceof Map<?,?> m2 && m2.containsKey("$__leaf") && m2.size()==1) {
          out.put(k, m2.get("$__leaf"));
        } else {
          out.put(k, sv);
        }
      } else {
        out.put(k, v);
      }
    }
    return out;
  }
}
