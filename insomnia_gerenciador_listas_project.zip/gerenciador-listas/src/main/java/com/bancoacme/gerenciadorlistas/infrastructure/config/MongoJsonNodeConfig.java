package com.bancoacme.gerenciadorlistas.infrastructure.config;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.bson.Document;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
import org.springframework.data.convert.WritingConverter;
import org.springframework.data.convert.ReadingConverter;

import java.util.List;
import java.util.Map;

@Configuration
public class MongoJsonNodeConfig {

    @Bean
    MongoCustomConversions mongoCustomConversions(ObjectMapper mapper) {
        return new MongoCustomConversions(List.of(
            new JsonNodeToDocumentConverter(mapper),
            new DocumentToJsonNodeConverter(mapper)
        ));
    }

    @WritingConverter
    static class JsonNodeToDocumentConverter implements Converter<JsonNode, Document> {
        private final ObjectMapper mapper;
        JsonNodeToDocumentConverter(ObjectMapper mapper){ this.mapper = mapper; }
        @Override public Document convert(JsonNode source) {
            Map<String,Object> map = mapper.convertValue(source, new TypeReference<Map<String,Object>>(){});
            return new Document(map);
        }
    }

    @ReadingConverter
    static class DocumentToJsonNodeConverter implements Converter<Document, JsonNode> {
        private final ObjectMapper mapper;
        DocumentToJsonNodeConverter(ObjectMapper mapper){ this.mapper = mapper; }
        @Override public JsonNode convert(Document source) {
            return mapper.valueToTree(source);
        }
    }
}
