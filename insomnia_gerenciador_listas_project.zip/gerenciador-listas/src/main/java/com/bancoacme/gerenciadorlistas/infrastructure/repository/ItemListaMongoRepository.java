package com.bancoacme.gerenciadorlistas.infrastructure.repository;

import com.bancoacme.gerenciadorlistas.infrastructure.repository.entity.ItemListaMongo;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ItemListaMongoRepository extends MongoRepository<ItemListaMongo, ObjectId> {
}
