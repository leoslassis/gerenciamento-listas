package com.bancoacme.gerenciadorlistas.domain.service;

import com.bancoacme.gerenciadorlistas.application.service.ValidadorJsonSchemaService;
import com.bancoacme.gerenciadorlistas.domain.exception.ListaNaoEncontradaException;
import com.bancoacme.gerenciadorlistas.domain.exception.ValidacaoException;
import com.bancoacme.gerenciadorlistas.domain.model.ItemLista;
import com.bancoacme.gerenciadorlistas.domain.model.Lista;
import com.bancoacme.gerenciadorlistas.domain.repository.ItemListaRepository;
import com.bancoacme.gerenciadorlistas.domain.repository.ListaRepository;
import com.bancoacme.gerenciadorlistas.infrastructure.index.UniqueIndexManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class ListaService {

    private final ListaRepository listaRepository;
    private final ItemListaRepository itemListaRepository;
    private final ValidadorJsonSchemaService validador;
    private final UniqueIndexManager uniqueIndexManager;

    public List<Lista> listarTodas() {
        log.info("Listando todas as listas");
        return listaRepository.listarTodas();
    }

    public Lista criarLista(Lista lista) {
        if (!lista.getNome().matches("^[a-z0-9]+(_[a-z0-9]+)*$")) {
            throw new ValidacaoException("O nome da lista deve estar em minúsculas, sem espaços, e palavras compostas separadas por underscore (_).");
        }

        // garante (idempotente) índices únicos declarados no schema dessa lista
        try {
            uniqueIndexManager.ensureUniqueIndexesForSchema(lista.getNome(), lista.getSchema());
        } catch (Exception e) {
            log.warn("Falha ao garantir índices únicos para a lista '{}': {}", lista.getNome(), e.getMessage());
        }

        Lista criada = listaRepository.salvar(lista);
        // invalida cache do schema
        try { validador.invalidarCache(criada.getNome()); } catch (Exception ignored) {}
        return criada;
    }

    public Lista buscarListaPorNome(String nome) {
        log.info("Buscando lista com nome: {}", nome);
        return listaRepository.buscarPorNome(nome)
                .orElseThrow(() -> new ListaNaoEncontradaException(nome));
    }

    public void removerLista(String nomeLista) {
        listaRepository.buscarPorNome(nomeLista)
                .orElseThrow(() -> new ListaNaoEncontradaException(nomeLista));

        itemListaRepository.removerTodosDaLista(nomeLista);
        listaRepository.removerPorNome(nomeLista);

        // invalida cache de schema, se houver
        try { validador.invalidarCache(nomeLista); } catch (Exception ignored) {}
    }

    public ItemLista adicionarItem(String nomeLista, Map<String, Object> dados) {
        Lista lista = buscarListaPorNome(nomeLista);
        validador.validar(nomeLista, lista.getSchema(), dados);

        // garante índices únicos do schema antes de persistir item (idempotente)
        try {
            uniqueIndexManager.ensureUniqueIndexesForSchema(nomeLista, lista.getSchema());
        } catch (Exception e) {
            log.warn("Falha ao garantir índices únicos antes de inserir item na lista '{}': {}", nomeLista, e.getMessage());
        }

        try {
            // >>> ajuste: construtor com dataInclusao (metadado) como null
            return itemListaRepository.salvar(new ItemLista(null, nomeLista, dados, null));
        } catch (DuplicateKeyException e) {
            String msg = "Violação de unicidade: já existe item com o mesmo valor em campo único desta lista.";
            log.warn("{} Lista='{}', dados={}, causa={}", msg, nomeLista, dados, e.getMessage());
            throw new ValidacaoException(msg);
        }
    }

    public List<ItemLista> buscarItens(String nomeLista, Map<String, Object> filtros) {
        log.info("Buscando itens da lista '{}' com filtros: {}", nomeLista, filtros);
        return itemListaRepository.buscar(nomeLista, filtros);
    }

    public ItemLista atualizarItem(String nomeLista, String idItem, Map<String, Object> dadosAtualizados) {
        Lista lista = buscarListaPorNome(nomeLista);
        validador.validar(nomeLista, lista.getSchema(), dadosAtualizados);

        // garante índices (caso um campo unique seja alterado)
        try {
            uniqueIndexManager.ensureUniqueIndexesForSchema(nomeLista, lista.getSchema());
        } catch (Exception e) {
            log.warn("Falha ao garantir índices únicos antes de atualizar item na lista '{}': {}", nomeLista, e.getMessage());
        }

        try {
            return itemListaRepository.atualizar(nomeLista, idItem, dadosAtualizados)
                    .orElseThrow(() -> new ValidacaoException("Item não encontrado ou não pôde ser atualizado."));
        } catch (DuplicateKeyException e) {
            String msg = "Violação de unicidade: já existe item com o mesmo valor em campo único desta lista.";
            log.warn("{} Lista='{}', dados={}, causa={}", msg, nomeLista, dadosAtualizados, e.getMessage());
            throw new ValidacaoException(msg);
        }
    }

    public void removerItem(String nomeLista, String idItem) {
        log.info("Removendo item '{}' da lista '{}'", idItem, nomeLista);
        itemListaRepository.remover(nomeLista, idItem);
    }

    public boolean verificarExistencia(String nomeLista, Map<String, Object> dados) {
        log.info("Verificando existência do item na lista '{}': {}", nomeLista, dados);
        return itemListaRepository.verificarExistencia(nomeLista, dados);
    }
}
