package com.bancoacme.gerenciadorlistas.infrastructure.repository;

import com.bancoacme.gerenciadorlistas.domain.model.ItemLista;
import com.bancoacme.gerenciadorlistas.domain.repository.ItemListaRepository;
import com.bancoacme.gerenciadorlistas.infrastructure.log.LogTempoExecucao;
import com.bancoacme.gerenciadorlistas.infrastructure.repository.entity.ItemListaMongo;
import com.bancoacme.gerenciadorlistas.infrastructure.repository.mapper.ItemListaMapper;
import lombok.RequiredArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.*;
import java.util.regex.Pattern;

@Component
@RequiredArgsConstructor
public class ItemListaRepositoryImpl implements ItemListaRepository {

    private final MongoTemplate mongoTemplate;
    private final ItemListaMongoRepository repository;

    @LogTempoExecucao("SALVAR_ITEM_LISTA_MONGO")
    @Override
    public ItemLista salvar(ItemLista item) {
        // dataInclusao automática
        ItemListaMongo mongo = new ItemListaMongo(
                null,
                item.getIdLista(),
                item.getDados(),
                Optional.ofNullable(item.getDataInclusao()).orElse(Instant.now())
        );
        return ItemListaMapper.toDomain(repository.save(mongo));
    }

    @LogTempoExecucao("BUSCAR_ITENS_LISTA_MONGO")
    @Override
    public List<ItemLista> buscar(String idLista, Map<String, Object> filtros) {
        Query query = new Query();
        query.addCriteria(Criteria.where("idLista").is(idLista));

        filtros.forEach((chave, valor) -> {
            if (valor == null) return;
            String path = "dados." + chave;

            if (valor instanceof String s) {
                String trimmed = s.trim();
                if (!trimmed.isEmpty()) {
                    Pattern regex = Pattern.compile(Pattern.quote(trimmed), Pattern.CASE_INSENSITIVE);
                    query.addCriteria(Criteria.where(path).regex(regex));
                }
            } else {
                query.addCriteria(Criteria.where(path).is(valor));
            }
        });

        return mongoTemplate.find(query, ItemListaMongo.class)
                .stream()
                .map(ItemListaMapper::toDomain)
                .toList();
    }

    @LogTempoExecucao("VERIFICAR_EXISTENCIA_ITEM_LISTA_MONGO")
    @Override
    public boolean verificarExistencia(String idLista, Map<String, Object> dados) {
        Query query = new Query();
        query.addCriteria(Criteria.where("idLista").is(idLista));
        dados.forEach((chave, valor) ->
                query.addCriteria(Criteria.where("dados." + chave).is(valor))
        );
        return mongoTemplate.exists(query, ItemListaMongo.class);
    }

    @LogTempoExecucao("ATUALIZAR_ITEM_LISTA_MONGO")
    @Override
    public Optional<ItemLista> atualizar(String idLista, String idItem, Map<String, Object> dadosAtualizados) {
        Optional<ItemListaMongo> existente = repository.findById(new ObjectId(idItem));
        if (existente.isEmpty() || !Objects.equals(existente.get().getIdLista(), idLista)) {
            return Optional.empty();
        }
        ItemListaMongo atualizado = existente.get();
        atualizado.setDados(dadosAtualizados);
        // NÃO alterar dataInclusao
        return Optional.of(ItemListaMapper.toDomain(repository.save(atualizado)));
    }

    @LogTempoExecucao("REMOVER_ITEM_LISTA_MONGO")
    @Override
    public void remover(String idLista, String idItem) {
        repository.findById(new ObjectId(idItem)).ifPresent(repository::delete);
    }

    @Override
    public void removerTodosDaLista(String idLista) {
        Query q = new Query(Criteria.where("idLista").is(idLista));
        mongoTemplate.remove(q, ItemListaMongo.class);
    }
}
