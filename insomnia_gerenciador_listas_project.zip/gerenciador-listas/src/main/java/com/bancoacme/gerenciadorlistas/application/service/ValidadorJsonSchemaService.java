package com.bancoacme.gerenciadorlistas.application.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class ValidadorJsonSchemaService {

    private final ObjectMapper mapper = new ObjectMapper();
    private final JsonSchemaFactory factory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7);
    private final Map<String, JsonSchema> cache = new ConcurrentHashMap<>();

    public void validar(String nomeLista, JsonNode schemaNode, Map<String, Object> dados) {
        if (schemaNode == null) return; // sem schema -> sem validação
        JsonSchema schema = cache.computeIfAbsent(nomeLista, k -> factory.getSchema(schemaNode));
        JsonNode data = mapper.valueToTree(dados);
        Set<ValidationMessage> errors = schema.validate(data);
        if (!errors.isEmpty()) {
            String msg = errors.stream().map(ValidationMessage::getMessage).reduce((a,b)->a+"; "+b).orElse("Inválido");
            throw new IllegalArgumentException("Dados inválidos: " + msg);
        }
    }

    public void invalidarCache(String nomeLista) {
        cache.remove(nomeLista);
    }
}
