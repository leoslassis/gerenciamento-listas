package com.bancoacme.gerenciadorlistas.infrastructure.repository.mapper;

import com.bancoacme.gerenciadorlistas.domain.model.ItemLista;
import com.bancoacme.gerenciadorlistas.infrastructure.repository.entity.ItemListaMongo;

public class ItemListaMapper {

    public static ItemLista toDomain(ItemListaMongo m) {
        if (m == null) return null;
        return new ItemLista(
                m.getId(),
                m.getIdLista(),
                m.getDados(),
                m.getDataInclusao()
        );
    }

    public static ItemListaMongo toMongo(ItemLista d) {
        if (d == null) return null;
        return new ItemListaMongo(
                d.getId(),
                d.getIdLista(),
                d.getDados(),
                d.getDataInclusao()
        );
    }
}
