package com.bancoacme.gerenciadorlistas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerenciadorListasApplication {
    public static void main(String[] args) {
        SpringApplication.run(GerenciadorListasApplication.class, args);
    }
}