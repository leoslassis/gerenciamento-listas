package com.bancoacme.gerenciadorlistas.infrastructure.index;

import com.bancoacme.gerenciadorlistas.infrastructure.repository.entity.ItemListaMongo;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.mongodb.core.index.IndexOperations;
import org.springframework.data.mongodb.core.index.PartialIndexFilter;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.Map;

/**
 * Cria índices únicos por lista para campos marcados como "unique": true no schema (JsonNode).
 * Ex.: campo "cpf" -> índice único composto { idLista:1, dados.cpf:1 } com filtro parcial
 *      { "dados.cpf": { $exists: true } } para permitir documentos sem o campo.
 *
 * Aceita schemas nos formatos:
 *   1) { "properties": { "cpf": { "type": "string", "unique": true }, ... } }
 *   2) { "cpf": { "type": "string", "unique": true }, ... }   // shorthand
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class UniqueIndexManager {

    private final MongoTemplate mongoTemplate;

    /**
     * Garante (idempotente) os índices únicos declarados no schema JSON.
     * @param nomeLista nome da lista (id lógico da lista)
     * @param schema JsonNode do schema desta lista
     */
    public void ensureUniqueIndexesForSchema(String nomeLista, JsonNode schema) {
        if (schema == null || schema.isNull() || schema.isMissingNode()) return;

        JsonNode props = extractPropertiesNode(schema);
        if (props == null || !props.isObject() || props.size() == 0) return;

        IndexOperations ops = mongoTemplate.indexOps(ItemListaMongo.class);

        Iterator<Map.Entry<String, JsonNode>> fields = props.fields();
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> entry = fields.next();
            String campo = entry.getKey();
            JsonNode def = entry.getValue();

            if (def != null && def.isObject()) {
                JsonNode uniqueNode = def.get("unique");
                boolean isUnique = uniqueNode != null && uniqueNode.isBoolean() && uniqueNode.asBoolean();

                if (isUnique) {
                    String idxName = sanitizeIndexName("uniq_" + nomeLista + "_" + campo);

                    Index index = new Index()
                            .named(idxName)
                            .on("idLista", Sort.Direction.ASC)
                            .on("dados." + campo, Sort.Direction.ASC)
                            .unique()
                            // partial: só impõe unicidade quando o campo existir
                            .partial(PartialIndexFilter.of(
                                    Criteria.where("dados." + campo).exists(true)
                            ));

                    log.info("Garantindo índice único '{}' (lista='{}', campo='{}')", idxName, nomeLista, campo);
                    ops.ensureIndex(index);
                }
            }
        }
    }

    /**
     * Aceita:
     *  - schema com "properties": {...}
     *  - schema shorthand (as próprias chaves já são os campos)
     */
    private JsonNode extractPropertiesNode(JsonNode schema) {
        if (schema == null) return null;
        JsonNode props = schema.get("properties");
        if (props != null && props.isObject()) return props;
        if (schema.isObject()) return schema; // shorthand
        return null;
    }

    private String sanitizeIndexName(String raw) {
        // nomes de índice do Mongo aceitam alfanumérico, ., -, _, evitamos outros
        return raw.replaceAll("[^a-zA-Z0-9_\\-\\.]", "_");
    }
}
