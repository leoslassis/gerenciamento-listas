package com.bancoacme.gerenciadorlistas.domain.repository;

import com.bancoacme.gerenciadorlistas.domain.model.Lista;

import java.util.Optional;
import java.util.List;

public interface ListaRepository {
    Lista salvar(Lista lista);
    Optional<Lista> buscarPorNome(String nome);
    List<Lista> listarTodas();
    void removerPorNome(String nome);
}