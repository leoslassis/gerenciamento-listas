package com.bancoacme.gerenciadorlistas.domain.model;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Lista {
    private String nome;
    private String descricao;
    private JsonNode schema;
}
